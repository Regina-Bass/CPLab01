# CPLab01
Uses swift to create an app that pulls and displays data (photos) from Tumblr's API using a network request 

Codepath Lab 01

## Things I learned
### How to install and use CocoaPods - (Ruby comes with new OS X installations)
                        sudo gem install -n /usr/local/bin cocoapods     # Install CocoaPods gem
                        pod setup                                        # Clones the CocoaPods specs repo to ~/.cocoapods
                        pod init                                         # * After navigating to project directory * adds pod then open .

### XCode shortcuts - 
                                CMD + N : New file
                        CMD + Shift + N : New Project
                        CMD + Shift + O : Navigate files
                                CMD + O : Open a file
                                CMD + B : Build
                        CMD + Shift + B : Analyze?
                        CMD + Shift + K : clean
                  
Opening Workspace as oppsed to CodeProj
Dequeued tables
                  

